import React,{useEffect} from 'react'
import { useNavigate } from 'react-router-dom'
import './Profile.css'

function Profile({  }) {
    const navigate = useNavigate()
    const dataLocal = JSON.parse(localStorage.getItem("loggedUser"))
    useEffect(() => {
        if (!JSON.parse(localStorage.getItem("loggedUser"))) {
          navigate('/login')
        }
      }, [])
    return (
        <div className="userprofileCard">
            <img src="https://tse4.mm.bing.net/th/id/OIP.SrAO_FhAeAWE95TAnRAyiQHaEc?pid=ImgDet&rs=1" alt="" />
            {dataLocal &&  <h2><strong>Name:</strong> { dataLocal.firstName} { dataLocal.lastName}</h2>}
            {dataLocal&&  <p><strong>Email:</strong> { dataLocal.email} </p>}
            {dataLocal &&  <p><strong>Gender:</strong> { dataLocal.gender} </p>}
            
        </div>
    )
}

export default Profile