import React from 'react'
import Avatar from '@material-ui/core/Avatar';
import '../css/MessageSender.css'
// import Postimage from '../Post/Postimage';

function MessageSender({handleSubmit,userInputVal,setUserInputVal}) {
 

  const getData = (e) => {
    const { value, name } = e.target;
    setUserInputVal(() => {
      return {
        ...userInputVal,
        [name]: value,
      };
    });
  }; 
 

  return (
    <div className='messageSender'>
      <div className='messageSender_top'>
        <Avatar />
       {JSON.parse(localStorage.getItem("loggedUser")) && <h4 className='fName'>{JSON.parse(localStorage.getItem("loggedUser")).firstName}</h4>}
        <form  onSubmit={handleSubmit}>
          <input type='text' name='postText' value={userInputVal.postText}  className='messageSender_input'
            placeholder={'Whats in your mind'} onChange={getData} required/>
          <input onChange={getData} name="postImage"
            placeholder='image Url (optional)' />
          {/* <Postimage /> */}
          <button className='submit-btn'  type='submit'>Post</button>
        </form>
      </div>
    </div>
  )
}

export default MessageSender